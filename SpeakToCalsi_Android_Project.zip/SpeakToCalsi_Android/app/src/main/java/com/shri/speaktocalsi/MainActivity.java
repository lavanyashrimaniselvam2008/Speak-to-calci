package com.shri.speaktocalsi;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.DecimalFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, matrixBox; EditText input; TextView answer, status; Spinner mode; TextToSpeech tts; SpeechRecognizer recognizer;
    final DecimalFormat df = new DecimalFormat("0.##########");
    @Override public void onCreate(Bundle b){ super.onCreate(b); buildUI();
        tts=new TextToSpeech(this, s->{}); }
    TextView tv(String s,int sp){ TextView v=new TextView(this); v.setText(s); v.setTextSize(sp); v.setPadding(16,10,16,10); return v; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); return b; }
    void buildUI(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(20,18,20,18); root.setBackgroundColor(0xFFF7F5FC);
        TextView title=tv("🎙️ Speak to Calsi",28); title.setGravity(Gravity.CENTER); title.setTextColor(0xFF6750A4); root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        status=tv("Voice calculator • Basic + Scientific + Matrix",14); status.setGravity(Gravity.CENTER); root.addView(status);
        mode=new Spinner(this); String[] ms={"Basic","Scientific","Matrix"}; mode.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,ms)); root.addView(mode);
        input=new EditText(this); input.setHint("Type an expression or tap 🎤 Speak"); input.setTextSize(19); input.setSingleLine(false); root.addView(input,new LinearLayout.LayoutParams(-1,120));
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button speak=btn("🎤 SPEAK"); Button calc=btn("CALCULATE"); row.addView(speak,new LinearLayout.LayoutParams(0,-2,1)); row.addView(calc,new LinearLayout.LayoutParams(0,-2,1)); root.addView(row);
        Button clear=btn("CLEAR"); root.addView(clear);
        matrixBox=new LinearLayout(this); matrixBox.setOrientation(LinearLayout.VERTICAL); root.addView(matrixBox);
        answer=tv("Answer will appear here",22); answer.setTextColor(0xFF1B1B1B); root.addView(answer);
        Button say=btn("🔊 SPEAK ANSWER"); root.addView(say);
        TextView help=tv("Examples: 25 plus 15 • 20 divided by 5 • sin 30 • sqrt 25 • 2 power 5\nMatrix: enter rows separated by ; and values by spaces. Example: 1 2; 3 4",13); root.addView(help);
        setContentView(root);
        mode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> p){} public void onItemSelected(AdapterView<?> p,View v,int pos,long id){updateMatrix(pos==2);}});
        speak.setOnClickListener(v->startVoice()); calc.setOnClickListener(v->calculate()); clear.setOnClickListener(v->{input.setText("");answer.setText("Answer will appear here");}); say.setOnClickListener(v->{ if(tts!=null)tts.speak(answer.getText().toString(),TextToSpeech.QUEUE_FLUSH,null,"ans");});
    }
    void updateMatrix(boolean show){ matrixBox.removeAllViews(); if(!show)return; TextView h=tv("Matrix mode: choose operation and enter A/B",16); matrixBox.addView(h); }
    void startVoice(){
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},10);return;}
        if(!SpeechRecognizer.isRecognitionAvailable(this)){status.setText("Speech recognition is not available on this phone");return;}
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-IN"); i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak your calculation");
        startActivityForResult(i,20);
    }
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d); if(r==20 && c==RESULT_OK && d!=null){ArrayList<String> a=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS); if(a!=null&&!a.isEmpty()){input.setText(a.get(0));status.setText("Voice captured ✓");calculate();}}}
    void calculate(){
        String s=input.getText().toString().trim(); if(s.isEmpty()){answer.setText("Please enter or speak a calculation");return;}
        try{String m=mode.getSelectedItem().toString(); if(m.equals("Basic")) answer.setText("= "+df.format(evalBasic(s))); else if(m.equals("Scientific")) answer.setText("= "+df.format(evalSci(s))); else answer.setText(evalMatrixText(s));}
        catch(Exception e){answer.setText("Error: "+e.getMessage());}
    }
    String norm(String s){s=s.toLowerCase(Locale.US).replace("multiplied by","*").replace("multiply by","*").replace("divided by","/").replace("divide by","/").replace("plus","+").replace("minus","-").replace("times","*").replace("modulus","%").replace(" mod ","%").replace("power","^").replace("x","*"); return s.replaceAll("\\s+","");}
    double evalBasic(String raw){ return new Parser(norm(raw)).parse(); }
    double evalSci(String raw){ String s=raw.toLowerCase(Locale.US).trim();
        s=s.replace("degrees","").trim();
        if(s.startsWith("sin"))return Math.sin(Math.toRadians(evalBasic(s.substring(3))));
        if(s.startsWith("cos"))return Math.cos(Math.toRadians(evalBasic(s.substring(3))));
        if(s.startsWith("tan"))return Math.tan(Math.toRadians(evalBasic(s.substring(3))));
        if(s.startsWith("sqrt"))return Math.sqrt(evalBasic(s.substring(4)));
        if(s.startsWith("square")) {double x=evalBasic(s.substring(6));return x*x;}
        if(s.startsWith("cube")) {double x=evalBasic(s.substring(4));return x*x*x;}
        if(s.startsWith("exp"))return Math.exp(evalBasic(s.substring(3)));
        if(s.startsWith("ln"))return Math.log(evalBasic(s.substring(2)));
        if(s.startsWith("log"))return Math.log10(evalBasic(s.substring(3)));
        if(s.startsWith("factorial")){int n=(int)evalBasic(s.substring(9)); if(n<0||n>170)throw new IllegalArgumentException("factorial range"); double f=1;for(int i=2;i<=n;i++)f*=i;return f;}
        return evalBasic(s);
    }
    String evalMatrixText(String s){
        String[] parts=s.split("\\|"); if(parts.length<2)throw new IllegalArgumentException("Matrix format: operation|A|B"); String op=parts[0].trim().toLowerCase(Locale.US); double[][] A=matrix(parts[1]);
        if(op.startsWith("det"))return "= "+df.format(det(A));
        if(parts.length<3)throw new IllegalArgumentException("Need matrix B"); double[][] B=matrix(parts[2]); double[][] C;
        if(op.startsWith("add"))C=add(A,B); else if(op.startsWith("sub"))C=sub(A,B); else if(op.startsWith("mul"))C=mul(A,B); else throw new IllegalArgumentException("Use determinant|A, add|A|B, sub|A|B or mul|A|B"); return fmt(C);
    }
    double[][] matrix(String x){String[] rs=x.trim().split(";"); double[][] a=new double[rs.length][];for(int i=0;i<rs.length;i++){String[] q=rs[i].trim().split("[ ,]+" );a[i]=new double[q.length];for(int j=0;j<q.length;j++)a[i][j]=Double.parseDouble(q[j]);}return a;}
    void same(double[][]a,double[][]b){if(a.length!=b.length||a[0].length!=b[0].length)throw new IllegalArgumentException("Matrix sizes must match");}
    double[][] add(double[][]a,double[][]b){same(a,b);double[][]c=new double[a.length][a[0].length];for(int i=0;i<a.length;i++)for(int j=0;j<a[0].length;j++)c[i][j]=a[i][j]+b[i][j];return c;}
    double[][] sub(double[][]a,double[][]b){same(a,b);double[][]c=new double[a.length][a[0].length];for(int i=0;i<a.length;i++)for(int j=0;j<a[0].length;j++)c[i][j]=a[i][j]-b[i][j];return c;}
    double[][] mul(double[][]a,double[][]b){if(a[0].length!=b.length)throw new IllegalArgumentException("A columns must equal B rows");double[][]c=new double[a.length][b[0].length];for(int i=0;i<a.length;i++)for(int j=0;j<b[0].length;j++)for(int k=0;k<b.length;k++)c[i][j]+=a[i][k]*b[k][j];return c;}
    double det(double[][]a){if(a.length!=a[0].length)throw new IllegalArgumentException("Determinant needs square matrix");int n=a.length;if(n==1)return a[0][0];if(n==2)return a[0][0]*a[1][1]-a[0][1]*a[1][0];double r=0;for(int c=0;c<n;c++){double[][]m=new double[n-1][n-1];for(int i=1;i<n;i++){int jj=0;for(int j=0;j<n;j++)if(j!=c)m[i-1][jj++]=a[i][j];}r+=(c%2==0?1:-1)*a[0][c]*det(m);}return r;}
    String fmt(double[][]a){StringBuilder s=new StringBuilder("=\\n");for(double[]r:a){for(double v:r)s.append(df.format(v)).append("   ");s.append("\\n");}return s.toString();}
    @Override protected void onDestroy(){if(tts!=null)tts.shutdown();super.onDestroy();}

    static class Parser {String s;int p=0;Parser(String x){s=x;}double parse(){double v=expr();if(p<s.length())throw new IllegalArgumentException("Invalid expression");return v;}double expr(){double v=term();while(p<s.length()){char c=s.charAt(p);if(c=='+'){p++;v+=term();}else if(c=='-'){p++;v-=term();}else break;}return v;}double term(){double v=pow();while(p<s.length()){char c=s.charAt(p);if(c=='*'){p++;v*=pow();}else if(c=='/'){p++;double d=pow();if(d==0)throw new ArithmeticException("divide by zero");v/=d;}else if(c=='%'){p++;v%=pow();}else break;}return v;}double pow(){double v=unary();if(p<s.length()&&s.charAt(p)=='^'){p++;v=Math.pow(v,pow());}return v;}double unary(){if(p<s.length()&&s.charAt(p)=='+'){p++;return unary();}if(p<s.length()&&s.charAt(p)=='-'){p++;return -unary();}if(p<s.length()&&s.charAt(p)=='('){p++;double v=expr();if(p>=s.length()||s.charAt(p)!=')')throw new IllegalArgumentException("missing )");p++;return v;}int st=p;while(p<s.length()&&(Character.isDigit(s.charAt(p))||s.charAt(p)=='.'))p++;if(st==p)throw new IllegalArgumentException("number expected");return Double.parseDouble(s.substring(st,p));}}
}
