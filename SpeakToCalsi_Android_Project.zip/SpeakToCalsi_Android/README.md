# Speak to Calsi — Android App

A standalone Android calculator based on the supplied Python calculator features: Basic, Scientific and Matrix calculations, voice input, and spoken answers.

## App name
**Speak to Calsi**

## Included
- 🎤 Android native speech recognition (English-India)
- Voice result automatically placed into the calculator input
- Basic: +, -, ×, ÷, %, parentheses and power
- Scientific: sin, cos, tan, sqrt, square, cube, exp, log, ln, factorial
- Matrix: determinant, addition, subtraction, multiplication
- 🔊 Text-to-speech answer
- Portrait phone UI and launcher icon

## Build
This project includes a GitHub Actions workflow. Upload the folder to a GitHub repository, open **Actions → Build Speak to Calsi APK → Run workflow**. When it finishes, download the artifact named `Speak-to-Calsi-debug-apk`, then install the APK on Android.

The app label is exactly **Speak to Calsi**.

Matrix input format: `operation|A|B`.
Examples:
- `determinant|1 2;3 4`
- `add|1 2;3 4|5 6;7 8`
- `sub|1 2;3 4|5 6;7 8`
- `mul|1 2;3 4|5 6;7 8`
